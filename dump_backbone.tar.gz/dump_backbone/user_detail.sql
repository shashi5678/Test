-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: swgllc
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_detail`
--

DROP TABLE IF EXISTS `user_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile_phone` varchar(20) DEFAULT NULL,
  `work_phone` varchar(20) DEFAULT NULL,
  `failed_attempt` smallint(6) DEFAULT NULL,
  `master_account_id` bigint(20) DEFAULT NULL,
  `sms_charge` float NOT NULL,
  `is_sms_charge_paid` enum('yes','no') NOT NULL DEFAULT 'no',
  `cart_items` text,
  `kyc_status` smallint(6) NOT NULL DEFAULT '0' COMMENT '0= not applied , 1=Approved, 2=Applied, 3=Rejected',
  `disapprove_reason` varchar(255) NOT NULL,
  `approved_by` smallint(6) NOT NULL COMMENT '1=admin,2-withPin',
  `payment_rights` int(2) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_idx` (`user_id`),
  KEY `user_detail_ibfk_1` (`master_account_id`),
  CONSTRAINT `user_detail_ibfk_1` FOREIGN KEY (`master_account_id`) REFERENCES `ep_master_account` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_detail_user_id_sf_guard_user_id` FOREIGN KEY (`user_id`) REFERENCES `sf_guard_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_detail`
--

LOCK TABLES `user_detail` WRITE;
/*!40000 ALTER TABLE `user_detail` DISABLE KEYS */;
INSERT INTO `user_detail` VALUES (1,2,'Shashi','Singh',NULL,'asasa','shashi05678@yahoo.com','+9911948880',NULL,NULL,NULL,0,'no','a:1:{i:0;O:16:\"PassportCartItem\":4:{s:21:\"\0NisCartItem\0app_type\";s:8:\"Passport\";s:19:\"\0NisCartItem\0app_id\";s:1:\"2\";s:21:\"\0NisCartItem\0app_name\";s:16:\"Mr singh shashi \";s:20:\"\0NisCartItem\0app_fee\";i:77;}}',0,'',0,0,'2014-10-22 15:00:26','2014-10-22 15:12:14',0,0,2,NULL),(2,3,'Shaikh','Zaid',NULL,'fsfsfsdfs','shaikhzaid1981@yahoo.in','+453453535',NULL,NULL,NULL,0,'no','a:1:{i:0;O:16:\"PassportCartItem\":4:{s:21:\"\0NisCartItem\0app_type\";s:8:\"Passport\";s:19:\"\0NisCartItem\0app_id\";s:7:\"7974851\";s:21:\"\0NisCartItem\0app_name\";s:28:\"Mr sdfsdfsfsdfs sdfdsfsdfsd \";s:20:\"\0NisCartItem\0app_fee\";i:77;}}',0,'',0,0,'2014-10-28 14:47:51','2014-10-28 14:48:16',0,0,3,NULL),(3,4,'xyz','www',NULL,'rgter','xyzwww58@yahoo.com','+9911948888',NULL,NULL,NULL,0,'no','a:1:{i:0;O:12:\"VisaCartItem\":4:{s:21:\"\0NisCartItem\0app_type\";s:8:\"Freezone\";s:19:\"\0NisCartItem\0app_id\";s:2:\"26\";s:21:\"\0NisCartItem\0app_name\";s:18:\"Mr fddfgfd dfgdfg \";s:20:\"\0NisCartItem\0app_fee\";i:50;}}',0,'',0,0,'2014-12-23 19:10:34','2014-12-23 19:12:46',0,0,4,NULL),(10,NULL,'Tarun','Seth',NULL,NULL,'subhashish@test.com',NULL,NULL,NULL,NULL,0,'no',NULL,0,'',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL,'234');
/*!40000 ALTER TABLE `user_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-17 19:17:48
