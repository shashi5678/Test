<?php
ini_set("display_errors", 1);
require 'Slim/Slim.php';

\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();

$app->get('/', 'getUsers');
$app->get('/users', 'getUsers');
$app->get('/users/:id', 'getUser');
$app->get('/users/search/:query', 'findByName');
$app->post('/users', 'addUser');
$app->put('/users/:id', 'updateUser');
$app->delete('/users/:id', 'deleteUser');

$app->run();

function getUsers() {
    $sql_query = "select `id`,`first_name`,`last_name`,`email`,`age` FROM user_detail ORDER BY first_name";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->query($sql_query);
        $users = $stmt->fetchAll(PDO::FETCH_OBJ);
        $dbCon = null;        
        echo json_encode($users);
    } catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
}

function getUser($id) {
    $sql = "SELECT `first_name`,`last_name`,`email`,`age` FROM user_detail WHERE id=:id";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);
        $stmt->bindParam("id", $id);
        $stmt->execute();
        $user = $stmt->fetchObject();
        $dbCon = null;
        echo json_encode($user);
    } catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
}

function addUser() {
    global $app;
    
    $req = json_decode($app->request()->getBody(),true); // Getting parameter with names
    $paramfirst_name = $req['firstname'];
    $paramlast_name = $req['lastname'];
    $paramEmail = $req['email'];
    $paramAge = $req['age'];    

    $sql = "INSERT INTO user_detail (`first_name`,`last_name`,`email`,`age`) VALUES (:first_name, :last_name, :email, :age)";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);
        $stmt->bindParam("first_name", $paramfirst_name);
        $stmt->bindParam("last_name", $paramlast_name);
        $stmt->bindParam("email", $paramEmail);
        $stmt->bindParam("age", $paramAge);
        $stmt->execute();
        $user = $dbCon->lastInsertId();
        $dbCon = null;
        echo json_encode($user);
    } catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
}

function updateUser($id) {
    
   
    global $app;    
    $req = json_decode($app->request()->getBody(),true); // Getting parameter with names
    
   
    $paramfirst_name = $req['firstname'];
    $paramlast_name = $req['lastname'];
    $paramEmail = $req['email'];
    $paramAge = $req['age'];  
    
   

    $sql = "UPDATE user_detail SET first_name=:first_name, last_name=:last_name, email=:email, age=:age WHERE id=:id";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);
        $stmt->bindParam("id", $id);
        $stmt->bindParam("first_name", $paramfirst_name);
        $stmt->bindParam("last_name", $paramlast_name);
        $stmt->bindParam("email", $paramEmail);
        $stmt->bindParam("age", $paramAge);
        
       
        $status = $stmt->execute();

        $dbCon = null;
        echo json_encode($status);
    } catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
}

function deleteUser($id) {
    
   
    $sql = "DELETE FROM user_detail WHERE id=:id";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);
        $stmt->bindParam("id", $id);
        $status = $stmt->execute();
        $dbCon = null;
        echo json_encode($status);
    } catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
}

function findByName($query) {
    $sql = "SELECT * FROM user_detail WHERE UPPER(first_name) LIKE :query OR UPPER(last_name) LIKE :query ORDER BY first_name";
    try {
        $dbCon = getConnection();
        $stmt = $dbCon->prepare($sql);
        $query = "%" . $query . "%";
        $stmt->bindParam("query", $query);
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_OBJ);
        $dbCon = null;
        echo json_encode($users);
    } catch (PDOException $e) {
        echo '{"error":{"text":' . $e->getMessage() . '}}';
    }
}

function getConnection() {
    try {
        $db_username = "root";
        $db_password = "root";
        $conn = new PDO('mysql:host=localhost;dbname=swgllc', $db_username, $db_password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
    }
    return $conn;
}

?>